Italian Special Solitaire 2.0
-----------------------------


The deck is the Piemotese Tarot, in dialect Tar�ck.
The ranking of the cards in the 4 Foundations is the same of the French
Tarot from lower to higher:
  1, 2, 3, 4, 5, 6, 7, 8, 9, 10, Fante (or Valletto in french Valet; Jack),
  Cavallo (or Cavaliere, Horse or Knight), Donna (Queen), Re (King).

Keybord instructions
--------------------
 Choose the option in the main menu with up and down arrow key and
 press the Enter button.
 Press the Esc button to exit the game.
 Press the N key to start a new game.


Italian help
------------
Look on ./data/help.pdf


Author
------
Igor Sarzi Sartori
http://www.invido.it


Date
----
14.12.2004


