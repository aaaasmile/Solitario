Solitario ver 1.6
-----------------

New ver 1.6
-----------
- Aggiornato librerie sdl
- Install per tutti gli utenti

New ver 1.4
-----------
-Aggiunto menu credits
-corretto bug: il re non veniva spostato su una pila vuota

New ver 1.3
--------
- Aggiunto menu gestione suono
- Aggiunta la possibilit� di cambiare settings durante una sessione

Ver 1.0
-------
Prima versione rilasciata


Introduzione
------------

Questa � la versione del famoso solitario che utilizza le 40 carte da briscola.

Comandi durante il gioco
------------------------
Tasto 'N'  : inizia una nuova partita
Tasto 'A'  : mostra un'animazione

Mazzi di carte supportati
------------------------- 
-Piacentine
-Bergamasche
-Bolognesi
-Trevisane
-Genovesi
-Milanesi
-Napoletane
-Piemontesi
-Romagnole
-Sarde
-Siciliane
-Toscane
-Trentine
-Triestine

Lingue
------
- Italiano
- Dialetto Bredese

Autore
------
Igor Sarzi Sartori
http://kickers.fabbricadigitale.it/briscola/index.php

Credits
-------
Il programma utilizza la libreria sdl che si trova su 
http://www.libsdl.org e la libreria drac sviluppata da Rico Roberto Zu�iga